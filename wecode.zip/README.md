# wecodefest.github.io

---

This project uses Sass as CSS preprocessor, and Gulp as task manager.

Install dependencies:

```bash
npm install gulp-sass gulp-htmlmin gulp-autoprefixer --save-dev
```

Generate CSS:
<pre>
gulp sass
</pre>

Generate minified index.html
<pre>
gulp minify
</pre>
